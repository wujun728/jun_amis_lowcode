package com.zhang.qiniuDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author zhang
 * @version 1.0
 * @date 2020/4/14 13:08
 */
@SpringBootApplication
public class QiNiuYunApplication {
    public static void main(String[] args) {
        SpringApplication.run(QiNiuYunApplication.class, args);
    }
}
