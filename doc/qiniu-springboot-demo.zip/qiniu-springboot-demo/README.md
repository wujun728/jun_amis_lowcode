# qiniu-springboot-demo
qiniu-springboot-demo
本项目基于springboot整合了七牛云存储技术:
1.里面七牛云的认证key都是笔者自己的;
2.封装了两个工具类:
  1).七牛云普通文件上传.
  2).七牛云断点续传的文件上传.
3.后期使用七牛云的话可以模仿这个项目中的两个工具类封装最新的七牛云api.
