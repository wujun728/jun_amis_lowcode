package com.sumslack.me;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.WebApplicationInitializer;
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@ComponentScan(basePackages= {"com.ruoyi","com.sumslack.me"})
public class MainApplication extends SpringBootServletInitializer implements WebApplicationInitializer{
    public static void main(String[] args) {
        SpringApplication.run(MainApplication.class, args);
    }
}
