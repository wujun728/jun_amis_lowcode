package com.erp.page;

/**
 *@类:PersonPage
 *@作者:zhangdaihao
 *@E-mail:zhangdaiscott@163.com
 *@日期:2011-12-25
 */

@SuppressWarnings("serial")
public class DemoPage extends BasePage implements java.io.Serializable {
}