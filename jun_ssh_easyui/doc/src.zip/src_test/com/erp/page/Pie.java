package com.erp.page;

public class Pie {
	
	private String name;
	
	private Double y;

	
	public Pie() {
		super();
	}

	public Pie(String name, Double y) {
		super();
		this.name = name;
		this.y = y;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getY() {
		return y;
	}

	public void setY(Double y) {
		this.y = y;
	}

	
	
}
