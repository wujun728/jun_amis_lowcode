package com.erp.service;

import java.util.List;

import com.erp.model.Warehouse;

public interface IWarehouseService
{

	List<Warehouse> findWarehouseListCombobox();

}
