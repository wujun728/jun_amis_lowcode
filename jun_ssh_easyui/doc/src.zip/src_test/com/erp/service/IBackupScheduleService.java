package com.erp.service;

import org.quartz.Job;

public interface IBackupScheduleService extends Job
{


}
