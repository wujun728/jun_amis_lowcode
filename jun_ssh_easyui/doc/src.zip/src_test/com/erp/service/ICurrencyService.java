package com.erp.service;

import java.util.List;

import com.erp.model.Currency;

public interface ICurrencyService
{

	List<Currency> findCurrencyList();

}
