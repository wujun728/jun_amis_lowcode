package com.erp.viewModel;

public class CheckBoxModel
{
	private String type;
	private Options options;
	public String getType()
	{
		return type;
	}
	public void setType(String type )
	{
		this.type = type;
	}
	public Options getOptions()
	{
		return options;
	}
	public void setOptions(Options options )
	{
		this.options = options;
	}
}
