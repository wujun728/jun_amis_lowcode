package com.erp.viewModel;

public class Options
{
	private boolean on=true;
	private boolean off=false;
	public boolean isOn()
	{
		return on;
	}
	public void setOn(boolean on )
	{
		this.on = on;
	}
	public boolean isOff()
	{
		return off;
	}
	public void setOff(boolean off )
	{
		this.off = off;
	}
}
