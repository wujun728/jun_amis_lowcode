package com.jun.common.report.printer;


public class PrinterCss {
  public PrinterCss() {
  }

}