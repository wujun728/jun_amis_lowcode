package com.jun.common.report.grouparithmetic;

import com.jun.common.report.ReportException;

public interface GroupArithmetic {
    public String getResult(double[] values) throws ReportException;
}