package com.jun.common;

/**
 * @author Wujun
 * @createTime   2011-3-27
 */
public interface GerneralService {

}
