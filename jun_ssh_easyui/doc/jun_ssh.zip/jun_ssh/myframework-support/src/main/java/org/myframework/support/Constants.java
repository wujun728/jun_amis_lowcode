package org.myframework.support;

public class Constants {
	public static final String PAGE_DEFAULT_LIMIT="10";
	
	public static final String CUR_LOGIN_ACCOUNT = "CUR_LOGIN_ACCOUNT";
}
