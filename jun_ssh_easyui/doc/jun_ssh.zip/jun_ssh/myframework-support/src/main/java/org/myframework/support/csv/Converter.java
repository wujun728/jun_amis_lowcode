package org.myframework.support.csv;

/**
 *
 * <ol>数据转化接口
 * <li>{@link FileSizeConverter }</li>
 *
 * </ol>
 * @see
 * @author Wujun
 * @since 1.0
 * @2015年6月24日
 *
 */
public interface Converter {
	 public String convert(Object value);
}
