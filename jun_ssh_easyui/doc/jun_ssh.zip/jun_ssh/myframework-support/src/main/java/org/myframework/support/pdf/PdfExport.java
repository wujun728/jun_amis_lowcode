package org.myframework.support.pdf;

import org.myframework.support.csv.CsvExport;

public interface PdfExport extends CsvExport {

}
