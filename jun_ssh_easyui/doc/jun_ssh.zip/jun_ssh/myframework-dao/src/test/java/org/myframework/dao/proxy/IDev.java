package org.myframework.dao.proxy;

public interface IDev {
	public void dev();
}
