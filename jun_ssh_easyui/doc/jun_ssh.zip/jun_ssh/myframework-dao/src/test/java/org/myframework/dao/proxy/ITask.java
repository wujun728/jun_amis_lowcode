package org.myframework.dao.proxy;

public interface ITask {
	public void execute();
}
