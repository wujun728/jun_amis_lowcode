package org.myframework.ioc;

public class DowJonesNewsPersister {

}
