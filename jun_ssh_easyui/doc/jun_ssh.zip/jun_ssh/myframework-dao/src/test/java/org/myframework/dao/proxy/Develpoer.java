package org.myframework.dao.proxy;

public class Develpoer implements IDev{

 

	@Override
	public void dev() {
		 System.out.println("Develpoer .........");
		
	}

}
