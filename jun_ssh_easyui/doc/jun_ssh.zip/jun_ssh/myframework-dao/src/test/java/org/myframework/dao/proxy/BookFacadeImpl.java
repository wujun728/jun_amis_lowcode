package org.myframework.dao.proxy;

public class BookFacadeImpl implements BookFacade {

	public BookFacadeImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addBook() {
		// TODO Auto-generated method stub
		 System.out.println("增加图书方法。。。");  
	}

}
