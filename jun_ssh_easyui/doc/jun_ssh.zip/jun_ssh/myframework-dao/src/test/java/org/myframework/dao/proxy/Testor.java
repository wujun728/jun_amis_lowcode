package org.myframework.dao.proxy;

public class Testor implements ITest {

	public Testor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void test() {
		System.out.println("test .........");
	}

}
