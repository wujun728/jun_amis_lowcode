package org.myframework.dao.genrictype;

public class Person<T> {

	public Person() {
		// TODO Auto-generated constructor stub
	}

}
