package org.myframework.dao.jpashowcase.dao;

public interface UserDaoPlus {

	public void printPlus();

}
