package org.myframework.dao.proxy;

public interface ITest {
void test();
}
