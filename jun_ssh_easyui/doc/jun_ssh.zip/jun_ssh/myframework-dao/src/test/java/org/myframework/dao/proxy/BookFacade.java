package org.myframework.dao.proxy;

public interface BookFacade {
	public void addBook();  
}
