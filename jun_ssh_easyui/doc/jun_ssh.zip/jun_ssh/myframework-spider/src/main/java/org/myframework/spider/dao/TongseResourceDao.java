package org.myframework.spider.dao;

import org.myframework.spider.entity.TongseResource;
import org.springframework.data.repository.CrudRepository;

public interface TongseResourceDao extends CrudRepository<TongseResource,String> {

}
